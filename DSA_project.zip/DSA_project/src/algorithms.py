import heapq

def dijkstra(graph, start, end, weight_type="distance"):
    distances = {node: float('inf') for node in graph}
    distances[start] = 0
    paths = {node: [] for node in graph}
    paths[start] = [[start]]
    priority_queue = [(0, start)]
    
    while priority_queue:
        current_weight, current_node = heapq.heappop(priority_queue)
        if current_node == end:
            break
        if current_weight > distances[current_node]:
            continue
        for neighbor in graph.get(current_node, []):
            weight = neighbor[weight_type]
            new_weight = current_weight + weight
            if new_weight < distances[neighbor["to"]]:
                distances[neighbor["to"]] = new_weight
                paths[neighbor["to"]] = [path + [neighbor["to"]] for path in paths[current_node]]
                heapq.heappush(priority_queue, (new_weight, neighbor["to"]))
            elif new_weight == distances[neighbor["to"]]:
                paths[neighbor["to"]].extend(path + [neighbor["to"]] for path in paths[current_node])
    
    return paths.get(end, []), distances.get(end, float('inf'))

def find_all_routes(graph, start, end, max_stops=5, path=None, routes=None):
    if path is None:
        path = []
    if routes is None:
        routes = []
    path = path + [start]
    
    # Check if current node is the target
    if start == end:
        # Only add the path if it meets the max_stops constraint
        # Number of stops = len(path) - 2 (e.g., [A, B] → 0 stops)
        if (len(path) - 2) <= max_stops:
            routes.append(path)
        return routes
    
    # Stop exploring if exceeds max_stops (stops = edges - 1)
    if (len(path) - 1) > max_stops + 1:  # Adjusted condition
        return routes
    
    for neighbor in graph.get(start, []):
        if neighbor["to"] not in path:  # Avoid cycles
            find_all_routes(graph, neighbor["to"], end, max_stops, path, routes)
    return routes