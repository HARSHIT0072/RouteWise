import json
import os

class HistoryManager:
    def __init__(self, file_path="data/history.json"):
        self.file_path = file_path
        self.history = []
        self._load_history()

    def _load_history(self):
        if os.path.exists(self.file_path):
            with open(self.file_path, "r") as f:
                self.history = json.load(f)

    def _save_history(self):
        with open(self.file_path, "w") as f:
            json.dump(self.history, f, indent=2)

    def add_itinerary(self, route, distance, cost):
        self.history.append({"route": route, "distance": distance, "cost": cost})
        self._save_history()

    def get_history(self):
        return self.history