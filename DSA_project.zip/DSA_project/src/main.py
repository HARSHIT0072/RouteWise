from graph import Graph
from algorithms import dijkstra, find_all_routes
from history import HistoryManager
from utils import validate_city, validate_max_stops
import json

def load_sample_data(graph):
    with open("data/cities.json", "r") as f:
        data = json.load(f)
        for route in data["routes"]:
            graph.add_edge(route["from"], route["to"], route["distance"], route["cost"])

def main():
    graph = Graph()
    history = HistoryManager()
    load_sample_data(graph)

    while True:
        print("\n=== Travel Planner ===")
        print("1. Find Shortest Path (Distance)")
        print("2. Find Cheapest Path (Cost)")
        print("3. Show All Route Options")
        print("4. View Itinerary History")
        print("5. Show Available States")
        print("6. Exit")
        choice = input("Choose an option: ").strip()

        if choice == "1":
            start = input("From: ").strip()
            end = input("To: ").strip()
            if not (validate_city(graph, start) and validate_city(graph, end)):
                print("Error: Invalid state names.")
                continue
            paths, min_distance = dijkstra(graph.graph, start, end, "distance")
            print(f"\nShortest Path(s) (Distance: {min_distance} km):")
            for i, path in enumerate(paths, 1):
                distance, cost = graph.calculate_metrics(path)
                print(f"{i}. {path} | Cost: ₹{cost}")
                history.add_itinerary(path, distance, cost)
        
        elif choice == "2":
            start = input("From: ").strip()
            end = input("To: ").strip()
            if not (validate_city(graph, start) and validate_city(graph, end)):
                print("Error: Invalid state names.")
                continue
            paths, min_cost = dijkstra(graph.graph, start, end, "cost")
            print(f"\nCheapest Path(s) (Cost: ₹{min_cost}):")
            for i, path in enumerate(paths, 1):
                distance, cost = graph.calculate_metrics(path)
                print(f"{i}. {path} | Distance: {distance} km")
                history.add_itinerary(path, distance, cost)
                
        elif choice == "3":
            start = input("From: ").strip()
            end = input("To: ").strip()
            max_stops = input("Max Stops (≥ 0, e.g., 0 for direct routes): ").strip()
            
            # Debug lines
            print(f"\nDebug: Start='{start}', Valid={validate_city(graph, start)}")
            print(f"Debug: End='{end}', Valid={validate_city(graph, end)}")
            print(f"Debug: Max Stops='{max_stops}', Valid={validate_max_stops(max_stops)}")
            if not (validate_city(graph, start) and validate_city(graph, end) and validate_max_stops(max_stops)):
                print("Error: Invalid input. Ensure states exist and max stops ≥ 0.")
                continue
            max_stops = int(max_stops)
            routes = find_all_routes(graph.graph, start, end, max_stops)
            print(f"\nAll Routes (Max {max_stops} stops):")
            if routes:
                for i, route in enumerate(routes, 1):
                    distance, cost = graph.calculate_metrics(route)
                    print(f"{i}. {route} | Distance: {distance} km | Cost: ₹{cost}")
            else:
                print("No routes found.")

        elif choice == "4":
            print("\n--- History ---")
            for entry in history.get_history():
                print(f"Route: {entry['route']} | Distance: {entry['distance']} km | Cost: ₹{entry['cost']}")

        elif choice == "5":
            states = graph.get_available_states()
            print("\n--- Available States ---")
            for state in states:
                print(f"- {state}")

        elif choice == "6":
            print("Exiting...")
            break

        else:
            print("Invalid choice!")

if __name__ == "__main__":
    main()