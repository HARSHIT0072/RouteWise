def validate_city(graph, city_name):
    """Check if a city exists in the graph."""
    return city_name in graph.get_cities()

def validate_max_stops(max_stops):
    """Ensure max_stops is a non-negative integer."""
    try:
        return int(max_stops) >= 0  # Allow 0 or higher
    except ValueError:
        return False