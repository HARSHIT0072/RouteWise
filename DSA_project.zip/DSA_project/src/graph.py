class Graph:
    def __init__(self):
        self.graph = {}  # { "CityA": [{"to": "CityB", "distance": 100, "cost": 50}, ...] }

    def add_edge(self, from_node, to_node, distance, cost):
        if from_node not in self.graph:
            self.graph[from_node] = []
        self.graph[from_node].append({"to": to_node, "distance": distance, "cost": cost})

    def get_cities(self):
        """Return a list of all cities in the graph."""
        return list(self.graph.keys())
    
    def get_available_states(self):
        states = set()
        # Add all source states
        states.update(self.graph.keys())
        # Add all destination states
        for neighbors in self.graph.values():
            for neighbor in neighbors:
                states.add(neighbor["to"])
        return sorted(states)  # Return sorted list
    
    def calculate_metrics(self, path):
        """Calculate total distance and cost for a given path."""
        total_distance = 0
        total_cost = 0
        for i in range(len(path) - 1):
            from_node = path[i]
            to_node = path[i + 1]
            for neighbor in self.graph.get(from_node, []):
                if neighbor["to"] == to_node:
                    total_distance += neighbor["distance"]
                    total_cost += neighbor["cost"]
                    break
        return total_distance, total_cost